import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Set;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


public class Main {
    
    public static Matrix mat;
    
	public static void main(String[] args) throws IOException
	{
		Data data = new Data();
		List<Airport> all = data.getData();
		
		Scanner inp = new Scanner(System.in);
		System.out.println("Enter the number of airports you want in the database:");
		int n = inp.nextInt();
		mat = new Matrix(n);
		List<Airport> topN = new LinkedList<Airport>();
		
		for(int i = 0; i < n; i++)
		{
			topN.add(all.get(i));
		}
				
		mat.fillMatrix(topN);
		
		System.out.println("Airports: ");
		String url = "https://www.iata.org/en/publications/directories/code-search/?airport.search=";
        for(int i = 0; i < n; i++) {
            if(i%5 == 0) {
                System.out.println();
            }
            
            String name = mat.names.get(i);
            Document d = Jsoup.connect(url + name.toLowerCase()).get();
            Elements h1 = d.select("tbody");
            String str = h1.get(1).text();
            str = str.substring(0, str.indexOf(name) - 1);
            System.out.print(i +": " + name + " - " + str +"\t");

        }
        System.out.println();
        
        System.out.println("Enter 0 to Quit; 1 for Flights w No Desired Layover; 2 for Flight w Desired Layover:");
        int response = inp.nextInt();
        
        while(response == 1 || response == 2) {
            if(response == 1) {
                System.out.println("Where do you wish to depart from? (Enter the Corresponding Number for the Airport)");
                int s = inp.nextInt();
                System.out.println("Where do you wish to go? (Enter the Corresponding Number for the Airport)");
                int t = inp.nextInt();
                
                dijkstra(mat.matrix, s, t);
                
                System.out.println("Enter 0 to Quit; 1 for Flights w No Desired Layover; 2 for Flight w Desired Layover:");
                response = inp.nextInt();
            } else {
                System.out.println("Where do you wish to depart from? (Enter the Corresponding Number for the Airport)");
                int s = inp.nextInt();
                
                System.out.println("Where do you wish to have a layover? (Enter the Corresponding Number for the Airport)");
                int l = inp.nextInt();
                
                System.out.println("Where do you wish to go? (Enter the Corresponding Number for the Airport)");
                int t = inp.nextInt();
                
                dijkstra(mat.matrix, s, l);
                dijkstra(mat.matrix, l, t);


                
                System.out.println("Enter 0 to Quit; 1 for Flights w No Desired Layover; 2 for Flight w Desired Layover:");
                response = inp.nextInt();
            }
        }
        
        System.out.println("Bye!");
        

		
		inp.close();
		
	}
	
	public static void dijkstra(int[][] adjMatrix, int source, int target) {
	    if(source < 0 || source >= adjMatrix.length || target < 0 || target >= adjMatrix.length) {
	        System.out.println("Invalid Airport");
	        return;
	    }
	    PriorityQueue<Entry> queue = new PriorityQueue<Entry>();
        int[] cost = new int[adjMatrix.length];
        int[] parent = new int[adjMatrix.length];
        boolean hasFailed = false;

        for (int i = 0; i < adjMatrix.length; i++) {
            if (i == source) {
                cost[i] = 0;
                queue.add(new Entry(i, cost[i], -1));
            } else {
                cost[i] = Integer.MAX_VALUE;
                queue.add(new Entry(i, cost[i], -1));
            }

        }

        Set<Integer> discovered = new HashSet<Integer>();

        while (!queue.isEmpty() && !hasFailed) {
            Entry minEntry = queue.poll();
            int node = minEntry.key;
            int par = minEntry.parent;
            Integer minVal = minEntry.value;

           
            if(!discovered.contains(node)) {
                discovered.add(node);
                parent[node] = par;
            }
            
            
            if (minVal.equals(Integer.MAX_VALUE)) {
                hasFailed = true;
                break;
            } else if(node == target) {
                break;
            } else {
                for (int i = 0; i < adjMatrix.length; i++) {
                    if (!discovered.contains(i) && adjMatrix[node][i] != 0 && i != node) {
                        if (cost[i] > cost[node] + adjMatrix[node][i]) {
                            cost[i] = cost[node] + adjMatrix[node][i];
                            queue.add(new Entry(i, cost[i], node));;
                        }
                    }
                }
            }
        }
        
        if(hasFailed) {
            System.out.println("No Path");
        } else {
            LinkedList<Integer> path = new LinkedList<Integer>();
            int curPar = target;
            
            while(curPar != source) {
                path.addFirst(curPar);
                curPar = parent[curPar];
            }
            
            path.addFirst(source);
            
            System.out.println("Path from " +mat.names.get(source)+ " to " +mat.names.get(target) +" is as follows:");
            
            for(int i : path) {
                if(i == path.getLast()) {
                    System.out.print(mat.names.get(i) + "   ");
                } else {
                    System.out.print(mat.names.get(i) + "  -->   ");
                }
            }
            
            System.out.println("\n For a Cost of: " +cost[target]);
            
        }
        
	}
	
	
	   public static class Entry implements Comparable<Entry> {
	        public int key;
	        public int value;
	        public int parent;

	        public Entry(int k, int v, int p) {
	            key = k;
	            value = v;
	            parent = p;
	        }

            @Override
            public int compareTo(Entry o) {
                // TODO Auto-generated method stub
                return Integer.compare(this.value, o.value);
            }
	    }



	
}
