
public class Airport implements Comparable<Airport>
{

		String name;
		int freq;
		
		Airport(String s, int f)
		{
			name = s;
			freq = f;
		}
		
		@Override
		public int compareTo(Airport a) {
			
	        return a.freq - this.freq;
	    }
		
		
}
