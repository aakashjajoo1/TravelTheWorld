import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Data {
	
	String baseURL;
	Document d;
	List<Airport> airports;
	Map<String, Integer> map;
	
	public Data() {
		try {
		this.baseURL = 
				"https://raw.githubusercontent.com/jpatokal/openflights/master/data/routes.dat";
		this.d = Jsoup.connect(this.baseURL).get();
		airports = new LinkedList<Airport>();
		} catch (Exception e) {
			System.out.println("Could not get the data :(");
		}
	}
	
	public void getFreqMapAndAirports(List<String> s)
	{
		map = new HashMap<String, Integer>();
		Iterator<String> it = s.iterator();
		while(it.hasNext())
		{
			String apt = it.next();	
			if(map.get(apt) == null)
			{
				map.put(apt, 1);
			}
			else
			{
				map.put(apt, map.get(apt) + 1);
			}	
		}
		
		Set<String> a = map.keySet();
		Iterator it1 = a.iterator();
	    while (it1.hasNext()) {
	        String pair = (String)it1.next();
	        airports.add(new Airport(pair, map.get(pair)));
	    }   
	    Collections.sort(airports);
	}
	
	
	public List<Airport> getData()
	{
		Elements articleElements = d.select("body");
		
		String a = articleElements.get(0).wholeText();		
		String[] str = a.split("\\R");
		String template = ",\\d*,(\\w*),\\d*,(\\w*),\\d*";
		Pattern p = Pattern.compile(template);
		Set<String> da = new TreeSet<String>();
		List<String> ls = new LinkedList<String>();
		for(int i = 0; i < str.length; i++)
		{
			Matcher m = p.matcher(str[i]);
			if(m.find())
			{
				ls.add(m.group(1));
				ls.add(m.group(2));
			}
		}
		getFreqMapAndAirports(ls);
		return airports;
	}
}

