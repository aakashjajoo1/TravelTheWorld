import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Matrix {
	
	int [][] matrix; 
	int [] front;
	int frontVal;
	static int max;
	boolean connected;
	Map<Integer, String> names;
	
	/**
	 * Constructor for the matrix, intializes all the instance variables.
	 * @param m: the number of nodes present in the graph
	 */
	Matrix(int m)
	{
		matrix = new int [m][m];
		front = new int[m];
		frontVal = -1;
		connected = true;
		names = new HashMap<Integer, String>();
	}
	
//	public void fillMatrix(String c1, String c2) throws IOException
//	{
//		if(!names.containsValue(c1))
//		{
//			names.put(names.size() + 1, c1);
//		}
//		
//		if(!names.containsValue(c2))
//		{
//			names.put(names.size() + 1, c2);
//		}
//		
//		Document d = Jsoup.connect("https://www.kayak.com/flights/"+ c1 + "-" + c2 +
//				"/2020-06-01?sort=price_a").get(); //Considering prices on 1st June, 2020
//		
//		Elements articleElements = d.select("span.price-text");
//		int price = 0;
//		
//		if(articleElements.size() != 0)
//		{
//				String price1 = articleElements.get(0).text().substring(1);
//				System.out.println(price1);
//				price = Integer.parseInt(price1);
//		}
//		
//		
//		
//	}
	
	
	public void fillMatrix(List<Airport> a) throws IOException
	{
		
		for(int i = 0; i < a.size(); i++)
		{
		    names.put(i, a.get(i).name);
			for(int j = 0; j < a.size(); j++)
			{
				if(i != j)
				{
					String name1 = a.get(i).name;
					String name2 = a.get(j).name;
					Document d = Jsoup.connect("https://www.kayak.com/flights/"+ name1 + "-" 
				   + name2 +
							"/2020-06-01?sort=price_a").get(); //Considering prices on 1st June, 2020
					
					Elements articleElements = d.select("span.price-text");
					int price = 0;
					
					if(articleElements.size() != 0)
					{
							String price1 = articleElements.get(0).text().substring(1);
							System.out.println("Price from " + name1 + " to " + name2 + " = " + price1);
							price = Integer.parseInt(price1);
					} else {
					    System.out.println("Search Failed");
					}
					
					matrix[i][j] = price;
				}
			}
		}
	}
	
}
